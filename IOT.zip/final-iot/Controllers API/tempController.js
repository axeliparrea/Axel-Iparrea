const mysql = require('../database/db');

class MainControllerTemperatura {
  async logTemp(req, res) {
    console.log(req.params.temperatura);
    console.log(req.params.ID_dispositivo);
    console.log(req.params.estatus);

    if (req.params.ID_dispositivo != null && req.params.temperatura != null && req.params.estatus != null) {
      let ID_dispositivo = req.params.ID_dispositivo;
      let temperatura = req.params.temperatura;
      let estatus = req.params.estatus;
      var sql = `insert into sensor_temperatura (ID_dispositivo, temperatura , estatus) values (${ID_dispositivo},${temperatura},${estatus});`
      mysql.query(sql, (error, data, fields) => {
        if (error) {
          res.status(500);
          res.send(error.message);
        } else {
          console.log(data);
          res.json({
            status: 200,
            message: "Log uploaded successfully",
            affectedRows: data.affectedRows
          });
        }
      });
    } else {
      res.send('Por favor llena todos los datos!');
    }
  }

  async getLogsTemperatura(req, res) {
    console.log("Get Logs");
    console.log(req.params.deviceID);

    if (req.params.ID_dispositivo != null) {
      let ID_dispositivo = req.params.ID_dispositivo;
      var sql = `insert into sensor_temperatura (ID_dispositivo) values (${ID_dispositivo});`
      mysql.query(sql, (error, data, fields) => {
        if (error) {
          res.status(500);
          res.send(error.message);
        } else {
          console.log(data);
          res.json(data);
        }
      });
    }
  }
}

const tempController = new MainControllerTemperatura();
module.exports = tempController;