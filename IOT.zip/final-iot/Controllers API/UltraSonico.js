const mysql = require('../database/db')

class MainControllerUltra {

    async Ultra(req , res){
        console.log(req.params.ID_dispositivo)
        console.log(req.params.distancia)
        if(req.params.ID_dispositivo != null && req.params.distancia != null) {
            let ID_dispositivo = req.params.ID_dispositivo
            let distancia = req.params.distancia;
            var sql = `insert into sensor_ultrasonico_afuera (ID_dispositivo, logDate, distancia) values (${ID_dispositivo},now(), ${distancia});`
            // var values = [ID_dispositivo, Estado_de_luz, Codigo_luz];
            mysql.query(sql, (error,data,fields) => {
                if(error) {
                    res.status(500)
                    res.send(error.message)
                } else {
                    console.log(data)
                    res.json({
                        status: 200,
                        message: "Log uploaded successfully",
                        affectedRows: data.affectedRows
                    })
                }
            })
        } else {
          res.send('Por favor llena todos los datos!')
        }
    }

    async logEstadoMotor(req , res){
        console.log(req.params.ID_dispositivo)
        console.log(req.params.estado)
        if(req.params.ID_dispositivo != null && req.params.estado != null) {
            let ID_dispositivo = req.params.ID_dispositivo
            let estado = req.params.estado;
            var sql = `insert into motor_metro (ID_dispositivo,logDate,estado) values (${ID_dispositivo},now(), ${estado});`
            mysql.query(sql, (error,data,fields) => {
                if(error) {
                    res.status(500)
                    res.send(error.message)
                } else {
                    console.log(data)
                    res.json({
                        status: 200,
                        message: "Log uploaded successfully",
                        affectedRows: data.affectedRows
                    })
                }
            })
        } else {
          res.send('Por favor llena todos los datos!')
        }
    }




    
    async getLogsUltra(req,res){
        console.log("Get Logs")
        console.log(req.params.ID_dispositivo)
        if(req.params.ID_dispositivo!=null){
            let ID_dispositivo = req.params.ID_dispositivo;
            var sql = `SELECT * FROM sensor_ultrasonico_afuera where ID_dispositivo='${ID_dispositivo}'`
            mysql.query(sql, (error, data, fields) => {
                if(error) {
                    res.status(500)
                    res.send(error.message)
                } else {
                    console.log(data)
                    res.json({
                        data
                    })
                }
            })
        }
    }
}

const UltraSonico = new MainControllerUltra()
module.exports = UltraSonico;