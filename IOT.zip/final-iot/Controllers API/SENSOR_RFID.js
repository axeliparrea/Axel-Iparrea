const mysql = require('../database/db')

class MainControllerRFID {

    async RFID(req , res){
        console.log(req.params.ID_dispositivo)
        console.log(req.params.password)
        console.log(req.params.estado_servo)

        // const { ID_dispositivo, Estado_de_luz, Codigo_luz } = req.body;
        if(req.params.ID_dispositivo != null && req.params.estado_servo != null && req.params.password != null) {
            let ID_dispositivo = req.params.ID_dispositivo
            let password = req.params.password;
            let estado_servo = req.params.estado_servo;

            var sql = `insert into sensor_rfid (ID_dispositivo, password , fecha, estado_servo) values (${ID_dispositivo},${password},now(),${estado_servo});`
            // var values = [ID_dispositivo, Estado_de_luz, Codigo_luz];
            mysql.query(sql, (error,data,fields) => {
                if(error) {
                    res.status(500)
                    res.send(error.message)
                } else {
                    console.log(data)
                    res.json({
                        status: 200,
                        message: "Log uploaded successfully",
                        affectedRows: data.affectedRows
                    })
                }
            })
        } else {
          res.send('Por favor llena todos los datos!')
        }
    }
    
    async getLogsRFID(req,res){
        console.log("Get Logs")
        console.log(req.params.ID_dispositivo)
        if(req.params.ID_dispositivo!=null){
            let ID_dispositivo = req.params.ID_dispositivo;
            var sql = `SELECT * FROM sensor_rfid where ID_dispositivo='${ID_dispositivo}'`
            mysql.query(sql, (error, data, fields) => {
                if(error) {
                    res.status(500)
                    res.send(error.message)
                } else {
                    console.log(data)
                    res.json({
                        data
                    })
                }
            })
        }
    }
}

const SENSOR_RFID = new MainControllerRFID()
module.exports = SENSOR_RFID;