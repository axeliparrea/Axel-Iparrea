const mysql = require('../database/db')

class MainControllerLDR {

    async SensorLuz(req , res){
        console.log(req.params.ID_dispositivo)
        console.log(req.params.Estado_de_luz)
        console.log(req.params.Codigo_luz)
        // const { ID_dispositivo, Estado_de_luz, Codigo_luz } = req.body;
        if(req.params.ID_dispositivo != null && req.params.Estado_de_luz != null && req.params.Codigo_luz != null) {
            let ID_dispositivo = req.params.ID_dispositivo
            let Codigo_luz = req.params.Codigo_luz;
            let Estado_de_luz = req.params.Estado_de_luz;
            var sql = `insert into sensor_de_luz (ID_dispositivo, Estado_de_luz, Codigo_luz) values (${ID_dispositivo}, ${Estado_de_luz}, ${Codigo_luz});`
            // var values = [ID_dispositivo, Estado_de_luz, Codigo_luz];
            mysql.query(sql, (error,data,fields) => {
                if(error) {
                    res.status(500)
                    res.send(error.message)
                } else {
                    console.log(data)
                    res.json({
                        status: 200,
                        message: "Log uploaded successfully",
                        affectedRows: data.affectedRows
                    })
                }
            })
        } else {
          res.send('Por favor llena todos los datos!')
        }
    }
    
    async getLogs(req,res){
        console.log("Get Logs")
        console.log(req.params.ID_dispositivo)
        if(req.params.ID_dispositivo!=null){
            let ID_dispositivo = req.params.ID_dispositivo;
            var sql = `SELECT * FROM sensor_de_luz where ID_dispositivo='${ID_dispositivo}'`
            mysql.query(sql, (error, data, fields) => {
                if(error) {
                    res.status(500)
                    res.send(error.message)
                } else {
                    console.log(data)
                    res.json({
                        data
                    })
                }
            })
        }
    }
}

const Controlador = new MainControllerLDR()
module.exports = Controlador;