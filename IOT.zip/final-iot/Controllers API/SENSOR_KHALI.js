const mysql = require('../database/db')

class MainControllerKHALI {

    async khali(req , res){
        console.log(req.params.ID_dispositivo)
        console.log(req.params.Estado)
        console.log(req.params.entrada)
        // console.log(req.params.ID_sensor)
        if(req.params.ID_dispositivo != null && req.params.Estado != null && req.params.entrada != null) {
            let ID_dispositivo = req.params.ID_dispositivo
            let entrada = req.params.entrada;
            let Estado = req.params.Estado;
           

            // let ID_sensor = req.params.ID_sensor;
            var sql = `insert into sensor_entrada (ID_dispositivo,entrada, logdate, Estado) values ('${ID_dispositivo}','${entrada}',now(), '${Estado}');`
            // var values = [ID_dispositivo, Estado_de_luz, Codigo_luz];
            mysql.query(sql, (error,data,fields) => {
                if(error) {
                    res.status(500)
                    res.send(error.message)
                } else {
                    console.log(data)
                    res.json({
                        status: 200,
                        message: "Log uploaded successfully",
                        affectedRows: data.affectedRows
                    })
                }
            })
        } else {
          res.send('Por favor llena todos los datos!')
        }
    }
    
    async getLogsK(req,res){
        console.log("Get Logs")
        console.log(req.params.ID_dispositivo)
        if(req.params.ID_dispositivo!=null){
            let ID_dispositivo = req.params.ID_dispositivo;
            var sql = `SELECT * FROM sensor_entrada where ID_dispositivo='${ID_dispositivo}'`
            mysql.query(sql, (error, data, fields) => {
                if(error) {
                    res.status(500)
                    res.send(error.message)
                } else {
                    console.log(data)
                    res.json({
                        data
                    })
                }
            })
        }
    }
}

const SENSOR_KHALI = new MainControllerKHALI()
module.exports = SENSOR_KHALI;