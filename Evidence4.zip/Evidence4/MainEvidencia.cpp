// Axel Eduardo Iparrea Ramos 
// A00836682
// ITC
// 12/01/2023

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_set>
#include <string>
#include <algorithm>

#include "Edge.h"
#include "Graph.h"
#include "hash.h"

using namespace std;

// Función para obtener el pivote en el quicksort
template <class T>
int getPivot(vector<T> &list, int left, int right) {
    int pivot = right;
    int auxIndex = left - 1;
    for (int index = left; index < right; index++) {
        if (list[index] < list[pivot]) {
            auxIndex++;
            swap(list[index], list[auxIndex]);
        }
    }
    auxIndex++;
    swap(list[auxIndex], list[pivot]);
    return auxIndex;
}

// Función de ordenamiento quicksort
template <class T>
void quickSort(vector<T> &list, int left, int right) {
    if (left < right) {
        int pivot = getPivot(list, left, right);
        quickSort(list, left, pivot - 1);
        quickSort(list, pivot + 1, right);
    }
}

int main() {
    ifstream fileIn("EuropeCities.csv");
    if (!fileIn) {
        cerr << "Error al abrir el archivo de entrada." << endl;
        return 1;
    }

    HashTableCities citiesHashTable; // Tabla hash para almacenar las ciudades únicas
    vector<Edge<string>> edges; // Vector para almacenar los bordes

    string line;
    getline(fileIn, line); // Descarta la primera línea (encabezado)

    while (getline(fileIn, line)) {
        stringstream ss(line);
        string cityA, cityB, timeByTrain, distanceByTrain, timeByCar, distanceByCar;

        getline(ss, cityA, ',');
        getline(ss, cityB, ',');
        getline(ss, timeByTrain, ',');
        getline(ss, distanceByTrain, ',');
        getline(ss, timeByCar, ',');
        getline(ss, distanceByCar, ',');

        // Almacenar las ciudades únicas en la tabla hash
        CityData cityData = {cityA, cityB, timeByTrain, distanceByTrain, timeByCar, distanceByCar};
        citiesHashTable.insert(cityData);

        // cout << "City inserted in hash table: " << cityA << ", " << cityB << endl; // Agregar esta línea para imprimir las ciudades insertadas

        edges.push_back({cityA, cityB, stoi(distanceByTrain)}); // Asumiendo que la distancia por tren es el peso
        edges.push_back({cityB, cityA, stoi(distanceByCar)}); // Asumiendo que la distancia por carro es el peso
    }

    fileIn.close();

    // Obtenemos todas las ciudades 
    vector<string> citiesVector = citiesHashTable.getAllCities();
    // cout << "Ciudades en citiesVector: " << endl;
    // for (const auto& city : citiesVector) {
    //     cout << city << endl;
    // }

    // Generar el grafo con la información obtenida de la tabla hash y los bordes
    Graph<string> myGraph(citiesVector, edges);
    cout << "Grafo generado: \n";
    // myGraph.print();

    int opcion;
    do {
        cout << "\n MENU \n" << endl;
        cout << "1) Ciudades ordenadas por alfabeto QUICKSORT" << endl;
        cout << "2) Adyacencias del grafo" << endl;
        cout << "3) Desplegar los recorridos del grafo" << endl;
        cout << "4) Ingresa dos ciudades para buscar la ruta mas corta" << endl;
        cout << "5) Salir" << endl;
        cout << "Ingresa tu opcion ";

        cin >> opcion;

        switch (opcion) {
            case 1: {
                vector<string> sortedCities = citiesHashTable.getAllCities(); // Obtener las ciudades desde la tabla hash
                quickSort(sortedCities, 0, sortedCities.size() - 1);

                ofstream fileOut1("output608-1.out");
                if (fileOut1.is_open()) {
                    for (const string& line : sortedCities) {
                        // cout << line << endl; // Imprime cada línea completa, Si queremos imprimir en la consola ponemos esta linea 
                        fileOut1 << line << endl;
                        
                    }
                    fileOut1.close();
                    cout << "Archivo creado output608-1.out" << endl;
                } else {
                    cerr << "No se pudo abrir el archivo de salida." << endl;
                }
                break;
            }
            case 2: {
                const string filename = "output608-2.out";
                ofstream fileOut2(filename);
                
                if (!fileOut2) {
                    cerr << "No se pudo abrir el archivo de salida." << endl;
                    break;
                }
                
                vector<string> allCities = citiesHashTable.getAllCities();
                for (const string& city : allCities) {
                    fileOut2 << city << ": ";
                    int cityIndex = myGraph.findVertex(city);
                    cout << "City: " << city << " Index: " << cityIndex << endl; // Impresión para verificar el índice de la ciudad
                    if (cityIndex != -1) {
                        const auto& adjacencyList = myGraph.getAdjacencyList();
                        for (const Edge<string>& edge : adjacencyList[cityIndex]) {
                            fileOut2 << edge.target << " ";
                        }
                    }
                    fileOut2 << '\n';
                }
                
                fileOut2.close();
                cout << "Archivo creado " << filename << endl;
                break;
            }

           

            case 3: {
                string startCity;
                cout << "Ingrese la ciudad de inicio: ";
                cin >> startCity;

                ofstream fileOut3("output608-3.out");
                ofstream fileOut4("output608-4.out");

                if (fileOut3.is_open() && fileOut4.is_open()) {
                    try {
                        myGraph.bfs(startCity); // Realizar el recorrido BFS desde la ciudad de inicio
                        myGraph.printToFile(fileOut3); // Escribir el resultado BFS en output608-3.out

                        // Recorrido dfs
                        myGraph.dfs(startCity); // Realizar el recorrido DFS desde la ciudad de inicio
                        myGraph.printToFile(fileOut4); // Escribir el resultado DFS en output608-4.out

                        fileOut3.close();
                        fileOut4.close();
                        cout << "Archivos creados output608-3.out y output608-4.out" << endl;
                    } catch (const invalid_argument& e) {
                        cerr << e.what() << endl; // Manejar el caso donde la ciudad de inicio no existe en el grafo
                    }
                } else {
                    cerr << "No se pudieron abrir los archivos de salida." << endl;
                }
                break;
            }
            case 4: {
                string city1, city2;
                cout << "Ingresa la primera ciudad: ";
                cin >> city1;
                cout << "Ingresa la segunda ciudad: ";
                cin >> city2;

                try {
                    int index1 = myGraph.findVertex(city1);
                    int index2 = myGraph.findVertex(city2);

                    if (index1 == -1 || index2 == -1) {
                        cout << "Alguna de las dos ciudades no existe en el grafo." << endl;
                        break;
                    }

                    // Obtener la ruta más corta por tren entre city1 y city2
                    cout << "Ruta más corta por tren de " << city1 << " a " << city2 << ":" << endl;
                    myGraph.dijkstra(city1, city2, "train");

                    // Obtener la ruta más corta por carro entre city1 y city2
                    cout << "Ruta más corta por carro de " << city1 << " a " << city2 << ":" << endl;
                    myGraph.dijkstra(city1, city2, "car");
                } catch (const invalid_argument& e) {
                    cout << e.what() << endl;
                }
                break;
            }




            // case 4: {
            //     string city1, city2;
            //     cout << "Ingresa la primera ciudad: ";
            //     cin >> city1;
            //     cout << "Ingresa la segunda ciudad: ";
            //     cin >> city2;

            //     try {
            //         // Obtener la ruta más corta por tren
            //         cout << "Ruta más corta por tren: " << endl;
            //         myGraph.dijkstra(city1, "train");
            //         cout << "-------------------------------" << endl;
            //         cout << "-------------------------------" << endl;
            //         cout << "-------------------------------" << endl;
            //         cout << "-------------------------------" << endl;
            //         cout << "-------------------------------" << endl;
            //         cout << "-------------------------------" << endl;
            //         cout << "-------------------------------" << endl;

            //         // Obtener la ruta más corta por carro
            //         cout << "Ruta más corta por carro: " << endl;
            //         myGraph.dijkstra(city1, "car");
            //     } catch (const invalid_argument& e) {
            //         cout << e.what() << endl;
            //     }
            //     break;
            // }



            case 5:
                cout << "Saliendo..." << endl;
                break;
            default:
                cout << "Opcion no valida." << endl;
                break;
        }

    } while (opcion != 5);

    return 0;
}
