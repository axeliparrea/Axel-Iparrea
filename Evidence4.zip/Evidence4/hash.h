#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <set>

using namespace std;

struct CityData {
    string cityA;
    string cityB;
    string timeByTrain;
    string distanceByTrain;
    string timeByCar;
    string distanceByCar;
};

class HashTableCities {
private:
    vector<vector<CityData>> table;
    int tableSize;

public:
    HashTableCities();
    void insert(const CityData& cityData);
    int hash(const string& city);
    int findCity(const string& city);
    void remove(const string& city);
    void print();
    vector<string> getAllCities(); 

};

HashTableCities::HashTableCities() {
    tableSize = 11;
    table.resize(tableSize);
}

int HashTableCities::hash(const string& city) {
    int sum = 0;
    for (char c : city) {
        sum += static_cast<int>(c);
    }
    return sum % tableSize;
}

void HashTableCities::insert(const CityData& cityData) {
    int index = hash(cityData.cityA);
    table[index].push_back(cityData);
}

int HashTableCities::findCity(const string& city) {
    int index = hash(city);
    for (size_t i = 0; i < table[index].size(); ++i) {
        if (table[index][i].cityA == city || table[index][i].cityB == city) {
            return static_cast<int>(i);
        }
    }
    return -1;
}

void HashTableCities::remove(const string& city) {
    int index = hash(city);
    int cityIndex = findCity(city);
    if (cityIndex != -1) {
        table[index].erase(table[index].begin() + cityIndex);
    }
}

void HashTableCities::print() {
    for (size_t i = 0; i < table.size(); ++i) {
        cout << "Bucket " << i << ": ";
        for (size_t j = 0; j < table[i].size(); ++j) {
            cout << "(" << table[i][j].cityA << " - " << table[i][j].cityB << ") ";
        }
        cout << endl;
    }
}

vector<string> HashTableCities::getAllCities() {
    set<string> citySet; // Utilizamos un set para mantener las ciudades ordenadas
    for (const auto& bucket : table) {
        for (const auto& cityData : bucket) {
            citySet.insert(cityData.cityA); // Insertamos las ciudades en el set
            citySet.insert(cityData.cityB);
        }
    }

    vector<string> cities; // Convertimos el set ordenado a un vector
    for (const auto& city : citySet) {
        // cout << "City retrieved from hash table: " << city << endl; 
        cities.push_back(city);
    }
    
    return cities;
}


// vector<string> HashTableCities::getAllCities() {
//     vector<string> cities;
//     for (const auto& bucket : table) {
//         for (const auto& cityData : bucket) {
//             if (find(cities.begin(), cities.end(), cityData.cityA) == cities.end()) {
//                 cities.push_back(cityData.cityA);
//             }
//             if (find(cities.begin(), cities.end(), cityData.cityB) == cities.end()) {
//                 cities.push_back(cityData.cityB);
//             }
//         }
//     }
//     return cities;
// }