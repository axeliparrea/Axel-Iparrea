#pragma once

template <class T>
struct Edge {
    T source;
    T target;
    int weight;
    int trainWeight; // Peso para la ruta por tren
    int carWeight;   // Peso para la ruta por carro

    Edge();
    Edge(T source, T target);
    Edge(T source, T target, int weight);
    Edge(T source, T target, int weight, int trainWeight, int carWeight);
};

template <class T>
Edge<T>::Edge() {
    weight = 0;
    trainWeight = 0;
    carWeight = 0;
}

template <class T>
Edge<T>::Edge(T source, T target) {
    this->source = source;
    this->target = target;
    this->weight = 0;
    this->trainWeight = 0;
    this->carWeight = 0;
}

template <class T>
Edge<T>::Edge(T source, T target, int weight) {
    this->source = source;
    this->target = target;
    this->weight = weight;
    this->trainWeight = weight; // Peso predeterminado igual al peso general
    this->carWeight = weight;   // Peso predeterminado igual al peso general
}

template <class T>
Edge<T>::Edge(T source, T target, int weight, int trainWeight, int carWeight) {
    this->source = source;
    this->target = target;
    this->weight = weight;
    this->trainWeight = trainWeight;
    this->carWeight = carWeight;
}
